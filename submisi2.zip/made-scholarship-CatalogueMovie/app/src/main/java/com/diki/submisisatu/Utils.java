package com.diki.submisisatu;

public class Utils {
    public static String parcel = "parcel";
}
